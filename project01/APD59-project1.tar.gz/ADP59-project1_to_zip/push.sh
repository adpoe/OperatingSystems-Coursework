scp library.c adp59@thoth.cs.pitt.edu:private/library.c
